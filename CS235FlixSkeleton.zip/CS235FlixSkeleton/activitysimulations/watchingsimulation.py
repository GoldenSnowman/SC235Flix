from domainmodel.movie import Movie
from domainmodel.user import User
from domainmodel.review import Review

class MovieWatchingSimulation:
    pass