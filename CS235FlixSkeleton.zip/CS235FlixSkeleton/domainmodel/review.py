from datetime import datetime

from domainmodel.movie import Movie


class Review:
    def __init__(self, movie: Movie, review_text: str, rating: int):
        self.__movie = movie
        self.__review_text = review_text.strip()
        if rating < 1 or rating > 10:
            self.__rating = None
        else:
            self.__rating = rating
        self.__timestamp = datetime.now()

    @property
    def movie(self) -> Movie:
        return self.__movie

    @movie.setter
    def movie(self, movie: Movie):
        self.__movie = movie

    @property
    def review_text(self) -> str:
        return self.__review_text

    @review_text.setter
    def review_text(self, review_text: str):
        self.__review_text = review_text.strip()

    @property
    def rating(self) -> int:
        return self.__rating

    @rating.setter
    def rating(self, rating: int):
        if rating < 1 or rating > 10:
            self.__rating = None
        else:
            self.__rating = rating

    @property
    def timestamp(self):
        return self.__timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        self.__timestamp = timestamp

    def __repr__(self):
        return f"<Review {self.__movie}, {self.__review_text}, {self.__rating }, {self.__timestamp}>"

    def __eq__(self, other):
        return (self.__movie, self.__review_text, self.__rating, self.__timestamp) == (other.__movie, other.__review_text, other.__rating, other.__timestamp)
