from domainmodel.genre import Genre
from domainmodel.actor import Actor
from domainmodel.director import Director


class Movie:
    def __init__(self, title: str, year: int):
        if title == "" or type(title) is not str:
            self.__title = None
        else:
            self.__title = title.strip()
        if year <= 1900 or type(year) is not int:
            self.__year = None
        else:
            self.__year = year

        self.__description = None
        self.__director = None
        self.__actors = []
        self.__genres = []
        self.__runtime_minutes = None
        self.__similar_movies = []
    @property
    def title(self) -> str:
        return self.__title

    @title.setter
    def title(self, title: str):
        if title == "" or type(title) is not str:
            self.__title = None
        else:
            self.__title = title.strip()

    @property
    def year(self) -> int:
        return self.__year

    @year.setter
    def year(self, year: int):
        if year <= 1900 or type(year) is not int:
            self.__year = None
        else:
            self.__year = year

    @property
    def description(self) -> str:
        return self.__description

    @description.setter
    def description(self, description: str):
        if description == "" or type(description) is not str:
            self.__description = None
        else:
            self.__description = description.strip()

    @property
    def director(self) -> Director:
        return self.__director

    @director.setter
    def director(self, director: Director):
        if type(director) is not Director:
            self.__director = None
        else:
            self.__director = director

    @property
    def actors(self) -> list:
        return self.__actors

    @actors.setter
    def actors(self, actors: list):
        if type(actors) is not list:
            self.__actors = []
        else:
            self.__actors = actors

    @property
    def genres(self) -> list:
        return self.__genres

    @genres.setter
    def genres(self, genres: list):
        if type(genres) is not list:
            self.__genres = []
        else:
            self.__genres = genres

    @property
    def runtime_minutes(self) -> int:
        return self.__runtime_minutes

    @runtime_minutes.setter
    def runtime_minutes(self, runtime_minutes: int):
        if runtime_minutes <= 0 :
            raise ValueError
        else:
            self.__runtime_minutes = runtime_minutes

    def __repr__(self):
        return f"<Movie {self.__title}, {self.__year}>"

    def __eq__(self, other):
        return (self.__title, self.__year) == (other.__title, other.__year)

    def __lt__(self, other):
        return (self.__title, self.__year) < (other.__title, other.__year)

    def __hash__(self):
        return hash((self.__title, self.__year))

    def add_actor(self, actor: Actor):
        if type(actor) is Actor:
            self.__actors.append(actor)

    def remove_actor(self, actor: Actor):
        if actor in self.__actors:
            self.__actors.remove(actor)

    def add_genre(self, genre: Genre):
        if type(genre) is Genre:
            self.__genres.append(genre)

    def remove_genre(self, genre: Genre):
        if genre in self.__genres:
            self.__genres.remove(genre)

    def add_similar_movies(self, movie):
        if movie not in self.__similar_movies:
            self.__similar_movies.append(movie)

    def similar_movies(self):
        return self.__similar_movies


class TestDirectorMethods:

    def test_init(self):
        movie1 = Movie("Super Hero Movie 1", 2016)
        movie2 = Movie("Super Hero Movie 2", 2017)
        movie1.add_similar_movies(movie2)
        assert movie1.similar_movies() == ["<Movie Super Hero Movie 2, 2017>"]
