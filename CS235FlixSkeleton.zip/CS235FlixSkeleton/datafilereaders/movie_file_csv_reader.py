import csv

from domainmodel.movie import Movie
from domainmodel.actor import Actor
from domainmodel.genre import Genre
from domainmodel.director import Director


class MovieFileCSVReader:

    def __init__(self, file_name: str):
        self.__file_name = file_name
        self.dataset_of_movies = []
        self.dataset_of_actors = set([])
        self.dataset_of_directors = set([])
        self.dataset_of_genres = set([])

    def read_csv_file(self):
        with open(self.__file_name, mode='r', encoding='utf-8-sig') as csvfile:
            movie_file_reader = csv.DictReader(csvfile)

            index = 0
            for row in movie_file_reader:
                title = row['Title']
                release_year = int(row['Year'])
                self.dataset_of_movies.append(Movie(title, release_year))
                director = row["Director"]
                d = Director(director)
                self.dataset_of_directors.add(d)
                genres = row["Genre"]
                for genre in genres.split(","):
                    g = Genre(genre)
                    self.dataset_of_genres.add(g)
                actors = row["Actors"]
                for actor in actors.split(","):
                    a = Actor(actor)
                    self.dataset_of_actors.add(a)

                index += 1



